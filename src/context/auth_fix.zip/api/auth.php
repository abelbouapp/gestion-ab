<?php
require_once 'config.php';

$db = getDB();

// Ensure users table exists
$db->exec("CREATE TABLE IF NOT EXISTS `app_users` (
  `email`    VARCHAR(255) PRIMARY KEY,
  `password` VARCHAR(255) NOT NULL,
  `name`     VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Seed default user if table is empty
$count = $db->query("SELECT COUNT(*) AS c FROM app_users")->fetch()['c'];
if ($count == 0) {
    $db->prepare("INSERT INTO app_users (email, password, name) VALUES (?,?,?)")
       ->execute(['abel@abelbou.com', 'abelbou2024', 'Abel Bou']);
}

$method = $_SERVER['REQUEST_METHOD'];
$b = body();

if ($method !== 'POST') {
    json_out(['error' => 'Method not allowed'], 405);
}

$action = $b['action'] ?? 'login';

if ($action === 'change_password') {
    $email   = $b['email']   ?? '';
    $current = $b['current'] ?? '';
    $next    = $b['next']    ?? '';

    $st = $db->prepare("SELECT * FROM app_users WHERE email=? AND password=?");
    $st->execute([$email, $current]);
    $u = $st->fetch();

    if (!$u) json_out(['error' => 'Contraseña actual incorrecta'], 401);

    $db->prepare("UPDATE app_users SET password=? WHERE email=?")
       ->execute([$next, $email]);

    json_out(['ok' => true]);
}

// Default: login
$email    = $b['email']    ?? '';
$password = $b['password'] ?? '';

$st = $db->prepare("SELECT * FROM app_users WHERE email=? AND password=?");
$st->execute([$email, $password]);
$u = $st->fetch();

if (!$u) {
    json_out(['error' => 'Email o contraseña incorrectos'], 401);
}

json_out(['email' => $u['email'], 'name' => $u['name']]);
